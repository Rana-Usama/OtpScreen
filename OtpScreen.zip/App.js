import React from 'react';

//screen
import OtpScreens from './app/screens/OtpScreens';

export default function App() {
  return (
    <OtpScreens />
  );
}


