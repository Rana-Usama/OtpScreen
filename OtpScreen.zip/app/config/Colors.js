export default {
    primary: '#493fba',
    grey: "#708097",
    inputFieldBorder: "rgba(195, 211, 212, 0.9)",
    inputFieldBackgroundColor: "rgba(242, 242, 242, 0.4)",
    inputFieldPlaceholder: "#9AA3AE",
    white: "#fff",
    black: "black",
    lightBlue: '#C0FAEB',
    warn: "#ba4848"
};
